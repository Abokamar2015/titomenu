
-- Create menu_items table
CREATE TABLE IF NOT EXISTS menu_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name_ar TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description_ar TEXT DEFAULT '',
  description_en TEXT DEFAULT '',
  price DECIMAL(10,2) NOT NULL,
  calories INTEGER DEFAULT NULL,
  category TEXT NOT NULL CHECK (category IN ('hot', 'cold', 'dessert', 'sandwich')),
  is_available BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;

-- Public read policy (customers can see available items)
CREATE POLICY "Public can read available menu items"
  ON menu_items FOR SELECT
  USING (true);

-- Allow all operations for authenticated users (admin)
CREATE POLICY "Admin can manage menu items"
  ON menu_items FOR ALL
  USING (true)
  WITH CHECK (true);

-- Auto-update updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_menu_items_updated_at
  BEFORE UPDATE ON menu_items
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert all menu data
INSERT INTO menu_items (name_ar, name_en, description_ar, description_en, price, calories, category, sort_order) VALUES
-- HOT DRINKS
('اسبريسو', 'Espresso', 'قهوة اسبريسو كلاسيكية', 'Classic espresso shot', 11.00, NULL, 'hot', 1),
('قهوة تركية & Co', '& Co Turkish Coffee', 'قهوة تركية كلاسيكية ممزوجة بالحليب الطازج لملمس ناعم وكريمي مع لمسة من الحليب المكثف', 'Classic Turkish coffee blended with fresh milk for a smooth and creamy texture, with a touch of condensed milk', 13.00, NULL, 'hot', 2),
('شاي كرك', 'Karak Tea', 'مزيج أصيل من أجود أنواع الشاي مع الحليب الكريمي والبهارات العطرية كالهيل والزعفران', 'Authentic blend of finest tea with creamy milk and aromatic spices like cardamom and saffron', 15.00, NULL, 'hot', 3),
('كابتشينو', 'Cappuccino', 'شات اسبريسو مع حليب مبخر وغطاء رغوي سميك لقوام مخملي فاخر', 'Espresso shot with steamed whole milk and thick rich foam for a luxurious velvety texture', 15.00, 940, 'hot', 4),
('فلات وايت', 'Flat White', 'اسبريسو مع حليب مبخر وميكروفوم، نكهة قهوة قوية وملمس ناعم', 'Espresso with steamed milk and microfoam for a bold coffee flavor and silky texture', 17.00, NULL, 'hot', 5),
('امريكانو', 'Americano', 'اسبريسو مع الماء الساخن', 'Espresso with hot water', 11.00, NULL, 'hot', 6),
('كورتادو', 'Cortado', 'شاتان من الريستريتو مع الحليب الدافئ الحريري في كوب أنيق', 'Two ristretto shots topped with warm, silky milk served in an elegant cup', 19.00, NULL, 'hot', 7),
('ماكياتو', 'Macchiato', 'اسبريسو مع كمية صغيرة من الحليب المبخر، مثالي لمحبي نكهة القهوة القوية', 'Espresso topped with a small amount of foamed milk, perfect for those who love bold coffee', 13.00, NULL, 'hot', 8),
('سبانش لاتيه', 'Spanish Latte', 'قهوة اسبريسو مع الحليب محلاة بالحليب المكثف لنكهة كريمية لذيذة', 'Espresso with your choice of milk, sweetened with condensed milk for a creamy taste', 20.00, NULL, 'hot', 9),
('هوت شوكليت & Co', '& Co Hot Chocolate', 'شراب دافئ غني يجمع الشوكولاتة الداكنة الناعمة مع الكريمة الفاخرة وقطعة وافل مقرمشة', 'Rich warm drink combining smooth dark chocolate with luxurious cream, topped with a crispy wafer', 31.00, NULL, 'hot', 10),
('قهوة اليوم', 'Coffee of the Day', 'قهوة مختارة بعناية لهذا اليوم', 'Carefully selected coffee of the day', 19.00, NULL, 'hot', 11),
-- COLD DRINKS
('آيس سبانش لاتيه', 'Ice Spanish Latte', 'لاتيه إسباني بارد مصنوع من اسبريسو وحليب وحليب مكثف على الثلج', 'Made with espresso, milk, and condensed milk served over ice', 23.00, NULL, 'cold', 1),
('آيسد امريكانو', 'Iced Americano', 'مزيج منعش من الاسبريسو والماء البارد مع مكعبات الثلج لطعم ناعم وخفيف', 'Refreshing blend of espresso and cold water with ice cubes for a smooth and mild taste', 13.00, NULL, 'cold', 2),
('آيسد كورتادو', 'Iced Cortado', 'اسبريسو طازج مع حليب بارد، مهزوز مع الثلج لإنشاء قهوة آيس كريمية', 'Fresh espresso, chilled milk, shaken with ice to create a creamy iced coffee', 15.00, NULL, 'cold', 3),
('آيس لاتيه', 'Ice Latte', 'اسبريسونا مع الحليب على الثلج — كل ما نحبه في لاتيه ساخن بدرجة حرارة أبرد', 'Our espresso combined with milk over ice — everything we love about a hot latte, cooler', 19.00, NULL, 'cold', 4),
('ماتشا & Co', '& Co Matcha', 'ماتشا خضراء عضوية احتفالية بنكهة نباتية غنية ولمسة من الحلاوة الطبيعية', 'Ceremonial organic green tea with complex vegetal flavor, natural sweetness and nuttiness', 28.00, NULL, 'cold', 5),
('عربي لاتيه', 'Arabic Latte', 'قهوة & Co الباردة الخاصة مع خيارك من الحليب وكريمة جوز الهند واسبريسو', '& Co Special Cold Coffee with choice of milk, coconut cream and espresso', 23.00, NULL, 'cold', 6),
('براون شوجر سينامون كولد فوم', 'Brown Sugar Cinnamon Cold Foam Coffee', 'قهوة باردة مع رغوة حليب مخملية مع نكهات السكر البني والقرفة الدافئة', 'Cold foam coffee infused with warm flavors of brown sugar and cinnamon', 38.00, NULL, 'cold', 7),
('حبيبي تي', 'Habibi Tea', 'شاي حبيبي المميز', 'Our special Habibi Tea blend', 28.00, NULL, 'cold', 8),
('كي تي', 'K Tea', 'مزيج شاي خاص', 'Special K Tea blend', 23.00, NULL, 'cold', 9),
('آيسد قهوة اليوم', 'Iced Coffee of the Day', 'قهوة اليوم باردة', 'Daily iced coffee special', 17.00, NULL, 'cold', 10),
('حليب حلو', 'Sweet Milk', 'حليب حلو منعش', 'Refreshing sweet milk', 19.00, NULL, 'cold', 11),
-- DESSERT
('كيكة سان سيباستيان', 'San Sebastian Cake', 'كيك جبن كريمي بنكهة السكر والبيض، يمكن مشاركته مع العائلة أو الأصدقاء', 'Cream cheese cake flavoured with sugar and eggs — perfect for sharing', 28.00, 214, 'dessert', 1),
('كريم بروليه', 'Crème Brûlée', 'حلوى ناعمة وغنية مع طبقة سكر كراميل مقرمشة لتجربة لا تُنسى', 'Soft and rich dessert with a crunchy caramelized sugar layer for an unforgettable experience', 30.00, 355, 'dessert', 2),
('كوكيز & Co', '&Co Cookies', 'كوكيز شوكولاتة فاخر بحواف مقرمشة وداخل طري مع قطع الشوكولاتة المذابة', 'Luxury chocolate cookies with crunchy edges and a soft heart with melted chocolate pieces', 19.00, 1002, 'dessert', 3),
('باين بيردو شوكولاتة', 'Pain Perdu Chocolate', 'توست فرنسي مخبوز مع شوكولاتة فاخرة', 'Baked pain perdu with luxurious chocolate', 35.00, 470, 'dessert', 4),
('باين بيردو توت', 'Pain Perdu Berry', 'توست فرنسي مخبوز مع التوت الطازج', 'Baked croissant pain perdu with berries', 38.00, NULL, 'dessert', 5),
('فرنش توست', 'French Toast', 'توست فرنسي كلاسيكي مع آيس كريم الفانيليا والتوت على الجانب', 'Classic French toast with a side of vanilla ice cream and berries', 35.00, 435, 'dessert', 6),
('هانيكومب بروفيترول', 'Honeycomb Profiterole', 'كيك بروفيترول مع صوص كراميل الفانيليا وقطع البروفيترول المقرمشة', 'Profiterole cake with house caramel sauce and crunchy honeycomb bites', 42.00, 481, 'dessert', 7),
('تشيز كيك', 'Cheesecake', 'مزيج خاص مع طبقة كراميل وقطرة من الذرة الحلوة', 'A special mix with caramelized topping and a hint of corn', 32.00, NULL, 'dessert', 8),
('بودينج & Co', '&Co Pudding', 'بودينج دافئ مع حلوى تركية', 'Warm pudding with Turkish delight', 32.00, 249, 'dessert', 9),
('كروسان سادة', 'Plain Croissant', 'كروسان طازج سادة', 'Fresh plain croissant', 13.00, NULL, 'dessert', 10),
('كروسان شوكولاتة', 'Chocolate Croissant', 'كروسان بالشوكولاتة الفاخرة', 'Croissant with luxurious chocolate', 17.00, 440, 'dessert', 11),
('براونيز', 'Brownies', 'براونيز شوكولاتة غنية', 'Rich chocolate brownies', 8.00, 170, 'dessert', 12),
-- SANDWICH
('ساندوتش تونة حارة', 'Spicy Tuna Sandwich', 'مزيج منعش من التونة مع صلصة الجبن الكريمي ودقة الفلفل الحار لنكهة متوازنة ومميزة', 'Refreshing tuna blend with spicy pepper sauce and creamy cheese for a balanced distinctive flavor', 27.00, 285, 'sandwich', 1),
('ساندوتش دجاج سيزر', 'Chicken Caesar Sandwich', 'خيار صحي لمحبي الطعام الخفيف مع خس الروميين والدجاج المشوي وصلصة سيزر', 'A healthy choice for light food lovers with romaine lettuce, grilled chicken and Caesar dressing', 28.00, 309, 'sandwich', 2),
('ساندوتش ديك رومي', 'Turkey Sandwich', 'مزيج مثالي من شرائح الديك الرومي الطازجة مع الجبن والخضار لتجربة شهية', 'Perfect blend of fresh turkey slices with cheese and vegetables for a satisfying experience', 30.00, 277, 'sandwich', 3);
