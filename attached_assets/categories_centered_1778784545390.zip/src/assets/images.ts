// Do not edit manually

export const IMAGES = {
  CROPPED_IMAGE_0_1777473782186812804_1: "/images/cropped_image_0_1777473782186812804.jpg",
  LOGO_2: "/images/LOGO.png",
} as const;

export type ImageKey = keyof typeof IMAGES;
