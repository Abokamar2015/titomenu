import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { ROUTE_PATHS } from '@/lib/constants';
import MenuPage from '@/pages/MenuPage';
import AdminPage from '@/pages/AdminPage';
import { Toaster } from '@/components/ui/sonner';

export default function App() {
  return (
    <Router>
      <div className="dark">
        <Routes>
          <Route path={ROUTE_PATHS.HOME} element={<MenuPage />} />
          <Route path={ROUTE_PATHS.MENU} element={<MenuPage />} />
          <Route path={ROUTE_PATHS.ADMIN} element={<AdminPage />} />
        </Routes>
        <Toaster richColors position="top-center" />
      </div>
    </Router>
  );
}
